let locked = true;

function updateTime()
{
    const now = new Date();

    document.getElementById("clock").innerHTML =
        now.toLocaleTimeString(
            "id-ID",
            {
                hour:"2-digit",
                minute:"2-digit"
            }
        );

    document.getElementById("date").innerHTML =
        now.toLocaleDateString(
            "id-ID",
            {
                weekday:"short",
                day:"2-digit",
                month:"short"
            }
        );
}

setInterval(updateTime,1000);

updateTime();

function toggleLock()
{
    const lockText =
        document.getElementById("lockText");

    const message =
        document.getElementById("message");

    const car =
        document.getElementById("carImage");

    locked = !locked;

    if(locked)
    {
        lockText.innerHTML =
            "LOCKED";

        lockText.className =
            "locked";

        message.innerHTML =
            "● Mobil Aman";

        message.style.color =
            "#00ff66";

        car.style.filter =
            "drop-shadow(0px 0px 20px #00aaff)";
    }
    else
    {
        lockText.innerHTML =
            "UNLOCKED";

        lockText.className =
            "locked unlocked";

        message.innerHTML =
            "○ Pintu Terbuka";

        message.style.color =
            "#ffaa00";

        car.style.filter =
            "drop-shadow(0px 0px 20px #ffaa00)";
    }
}